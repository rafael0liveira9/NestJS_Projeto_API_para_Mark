--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Ubuntu 15.1-1.pgdg20.04+1)
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: postgres; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE postgres SET "app.settings.jwt_secret" TO 'dfBEx/zoCZMENzEiQdxR2Nzb+aN47WNya7BwQBVirSWopCOTalZarut+2a1ax9nSJYwHQRFqnlaom7ssdUGu6A==';
ALTER DATABASE postgres SET "app.settings.jwt_exp" TO '3600';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO supabase_admin;

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO pgbouncer;

--
-- Name: pgsodium; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA pgsodium;


ALTER SCHEMA pgsodium OWNER TO supabase_admin;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO supabase_admin;

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO supabase_admin;

--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- Name: EspecificationTypes; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EspecificationTypes" AS ENUM (
    'EMPRESA',
    'PRODUTO',
    'SERVICO'
);


ALTER TYPE public."EspecificationTypes" OWNER TO postgres;

--
-- Name: FormatStyles; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."FormatStyles" AS ENUM (
    'QUADRADA',
    'REDONDA',
    'RETANGULAR_HORIZONTAL',
    'RETANGULAR_VERTICAL',
    'NONE'
);


ALTER TYPE public."FormatStyles" OWNER TO postgres;

--
-- Name: MediaFormat; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."MediaFormat" AS ENUM (
    'FEED',
    'STORIES',
    'REELS'
);


ALTER TYPE public."MediaFormat" OWNER TO postgres;

--
-- Name: NetworkTypes; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."NetworkTypes" AS ENUM (
    'FACEBOOK',
    'INSTAGRAM',
    'TIKTOK',
    'YOUTUBE',
    'LINKEDIN'
);


ALTER TYPE public."NetworkTypes" OWNER TO postgres;

--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'WAITING',
    'FINISHED_PAYMENT',
    'SENDED_TO_ASANA'
);


ALTER TYPE public."PaymentStatus" OWNER TO postgres;

--
-- Name: SiteModels; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SiteModels" AS ENUM (
    'ONEPAGE',
    'MULTIPAGE',
    'LANDPAGE',
    'MOBILEFIRST',
    'NONE'
);


ALTER TYPE public."SiteModels" OWNER TO postgres;

--
-- Name: SocialFeedShowType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SocialFeedShowType" AS ENUM (
    'VIDEO',
    'IMAGE',
    'ARRAY_IMAGE'
);


ALTER TYPE public."SocialFeedShowType" OWNER TO postgres;

--
-- Name: SocialImageBase; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SocialImageBase" AS ENUM (
    'BANCO',
    'CLIENTE',
    'AMBAS'
);


ALTER TYPE public."SocialImageBase" OWNER TO postgres;

--
-- Name: SocialMaterialQuant; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SocialMaterialQuant" AS ENUM (
    'DIARIO',
    'SEMANAL',
    'MENSAL'
);


ALTER TYPE public."SocialMaterialQuant" OWNER TO postgres;

--
-- Name: SocialServiceTypes; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SocialServiceTypes" AS ENUM (
    'PLANEJAMENTO_GERAL',
    'PLANEJAMENTO_REDACIONAL',
    'PLANEJAMENTO_VISUAL',
    'PLANEJAMENTO_POSTAGENS',
    'PLANEJAMENTO_GESTAO'
);


ALTER TYPE public."SocialServiceTypes" OWNER TO postgres;

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  schema_is_cron bool;
BEGIN
  schema_is_cron = (
    SELECT n.nspname = 'cron'
    FROM pg_event_trigger_ddl_commands() AS ev
    LEFT JOIN pg_catalog.pg_namespace AS n
      ON ev.objid = n.oid
  );

  IF schema_is_cron
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;

  END IF;

END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO postgres;

--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: postgres
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;
    END IF;

END;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
    ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

    ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
    ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

    REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
    REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

    GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO postgres;

--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: postgres
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: postgres
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RAISE WARNING 'PgBouncer auth request: %', p_usename;

    RETURN QUERY
    SELECT usename::TEXT, passwd::TEXT FROM pg_catalog.pg_shadow
    WHERE usename = p_usename;
END;
$$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO postgres;

--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
_filename text;
BEGIN
    select string_to_array(name, '/') into _parts;
    select _parts[array_length(_parts,1)] into _filename;
    -- @todo return the last part instead of 2
    return split_part(_filename, '.', 2);
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
    select string_to_array(name, '/') into _parts;
    return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
    select string_to_array(name, '/') into _parts;
    return _parts[1:array_length(_parts,1)-1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::int) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO supabase_storage_admin;

--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
  v_order_by text;
  v_sort_order text;
begin
  case
    when sortcolumn = 'name' then
      v_order_by = 'name';
    when sortcolumn = 'updated_at' then
      v_order_by = 'updated_at';
    when sortcolumn = 'created_at' then
      v_order_by = 'created_at';
    when sortcolumn = 'last_accessed_at' then
      v_order_by = 'last_accessed_at';
    else
      v_order_by = 'name';
  end case;

  case
    when sortorder = 'asc' then
      v_sort_order = 'asc';
    when sortorder = 'desc' then
      v_sort_order = 'desc';
    else
      v_sort_order = 'asc';
  end case;

  v_order_by = v_order_by || ' ' || v_sort_order;

  return query execute
    'with folders as (
       select path_tokens[$1] as folder
       from storage.objects
         where objects.name ilike $2 || $3 || ''%''
           and bucket_id = $4
           and array_length(regexp_split_to_array(objects.name, ''/''), 1) <> $1
       group by folder
       order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(regexp_split_to_array(objects.name, ''/''), 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

--
-- Name: secrets_encrypt_secret_secret(); Type: FUNCTION; Schema: vault; Owner: supabase_admin
--

CREATE FUNCTION vault.secrets_encrypt_secret_secret() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		BEGIN
		        new.secret = CASE WHEN new.secret IS NULL THEN NULL ELSE
			CASE WHEN new.key_id IS NULL THEN NULL ELSE pg_catalog.encode(
			  pgsodium.crypto_aead_det_encrypt(
				pg_catalog.convert_to(new.secret, 'utf8'),
				pg_catalog.convert_to((new.id::text || new.description::text || new.created_at::text || new.updated_at::text)::text, 'utf8'),
				new.key_id::uuid,
				new.nonce
			  ),
				'base64') END END;
		RETURN new;
		END;
		$$;


ALTER FUNCTION vault.secrets_encrypt_secret_secret() OWNER TO supabase_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    from_ip_address inet,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: Archives; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Archives" (
    id integer NOT NULL,
    url text NOT NULL,
    "companiesId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    "siteBriefingId" integer
);


ALTER TABLE public."Archives" OWNER TO postgres;

--
-- Name: Archives_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Archives_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Archives_id_seq" OWNER TO postgres;

--
-- Name: Archives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Archives_id_seq" OWNED BY public."Archives".id;


--
-- Name: Cards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Cards" (
    id integer NOT NULL,
    "nameCard" text NOT NULL,
    type text NOT NULL,
    description text NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    steps jsonb NOT NULL,
    "typeCard" integer NOT NULL,
    "whoDoing" integer,
    "clientId" integer NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    "companiesId" integer
);


ALTER TABLE public."Cards" OWNER TO postgres;

--
-- Name: Cards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Cards_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Cards_id_seq" OWNER TO postgres;

--
-- Name: Cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Cards_id_seq" OWNED BY public."Cards".id;


--
-- Name: Client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Client" (
    id integer NOT NULL,
    name text NOT NULL,
    document text NOT NULL,
    "documentType" text NOT NULL,
    phone text NOT NULL,
    cep text NOT NULL,
    "costumerId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    "userId" integer NOT NULL,
    "companiesId" integer
);


ALTER TABLE public."Client" OWNER TO postgres;

--
-- Name: Client_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Client_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Client_id_seq" OWNER TO postgres;

--
-- Name: Client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Client_id_seq" OWNED BY public."Client".id;


--
-- Name: Companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Companies" (
    id integer NOT NULL,
    "companyName" text NOT NULL,
    document text NOT NULL,
    "documentType" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    "ownerId" integer
);


ALTER TABLE public."Companies" OWNER TO postgres;

--
-- Name: Companies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Companies_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Companies_id_seq" OWNER TO postgres;

--
-- Name: Companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Companies_id_seq" OWNED BY public."Companies".id;


--
-- Name: ContratedService; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ContratedService" (
    id integer NOT NULL,
    "companiesId" integer NOT NULL
);


ALTER TABLE public."ContratedService" OWNER TO postgres;

--
-- Name: ContratedService_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ContratedService_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ContratedService_id_seq" OWNER TO postgres;

--
-- Name: ContratedService_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ContratedService_id_seq" OWNED BY public."ContratedService".id;


--
-- Name: Employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employee" (
    id integer NOT NULL,
    name text NOT NULL,
    "documentType" text NOT NULL,
    document text NOT NULL,
    phone text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    "userId" integer
);


ALTER TABLE public."Employee" OWNER TO postgres;

--
-- Name: Employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Employee_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Employee_id_seq" OWNER TO postgres;

--
-- Name: Employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Employee_id_seq" OWNED BY public."Employee".id;


--
-- Name: Errors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Errors" (
    id integer NOT NULL,
    "errorCode" integer NOT NULL,
    message text NOT NULL,
    "userId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone
);


ALTER TABLE public."Errors" OWNER TO postgres;

--
-- Name: Errors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Errors_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Errors_id_seq" OWNER TO postgres;

--
-- Name: Errors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Errors_id_seq" OWNED BY public."Errors".id;


--
-- Name: Images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Images" (
    id integer NOT NULL,
    url text NOT NULL,
    title text NOT NULL,
    author text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone
);


ALTER TABLE public."Images" OWNER TO postgres;

--
-- Name: Images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Images_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Images_id_seq" OWNER TO postgres;

--
-- Name: Images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Images_id_seq" OWNED BY public."Images".id;


--
-- Name: Lead; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Lead" (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    "subscribeAt" timestamp(3) without time zone
);


ALTER TABLE public."Lead" OWNER TO postgres;

--
-- Name: Lead_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Lead_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Lead_id_seq" OWNER TO postgres;

--
-- Name: Lead_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Lead_id_seq" OWNED BY public."Lead".id;


--
-- Name: LogoArchives; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LogoArchives" (
    id integer NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    url text NOT NULL,
    "previewId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    "logoServiceId" integer
);


ALTER TABLE public."LogoArchives" OWNER TO postgres;

--
-- Name: LogoArchives_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LogoArchives_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."LogoArchives_id_seq" OWNER TO postgres;

--
-- Name: LogoArchives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LogoArchives_id_seq" OWNED BY public."LogoArchives".id;


--
-- Name: LogoBriefing; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LogoBriefing" (
    id integer NOT NULL,
    format public."FormatStyles" NOT NULL,
    cores jsonb NOT NULL,
    typography text,
    especification public."EspecificationTypes" NOT NULL,
    description text,
    "references" text,
    titlefirst text,
    titlesecond text
);


ALTER TABLE public."LogoBriefing" OWNER TO postgres;

--
-- Name: LogoBriefing_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LogoBriefing_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."LogoBriefing_id_seq" OWNER TO postgres;

--
-- Name: LogoBriefing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LogoBriefing_id_seq" OWNED BY public."LogoBriefing".id;


--
-- Name: LogoContratedItems; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LogoContratedItems" (
    id integer NOT NULL,
    "contratedServiceId" integer NOT NULL,
    "logoServiceId" integer NOT NULL
);


ALTER TABLE public."LogoContratedItems" OWNER TO postgres;

--
-- Name: LogoContratedItems_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LogoContratedItems_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."LogoContratedItems_id_seq" OWNER TO postgres;

--
-- Name: LogoContratedItems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LogoContratedItems_id_seq" OWNED BY public."LogoContratedItems".id;


--
-- Name: LogoFeedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LogoFeedback" (
    id integer NOT NULL,
    stars double precision NOT NULL,
    comments text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone
);


ALTER TABLE public."LogoFeedback" OWNER TO postgres;

--
-- Name: LogoFeedback_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LogoFeedback_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."LogoFeedback_id_seq" OWNER TO postgres;

--
-- Name: LogoFeedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LogoFeedback_id_seq" OWNED BY public."LogoFeedback".id;


--
-- Name: LogoProof; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LogoProof" (
    id integer NOT NULL,
    "isApproved" boolean,
    "reasonRefuse" text,
    "imagesId" integer NOT NULL,
    "userSended" boolean
);


ALTER TABLE public."LogoProof" OWNER TO postgres;

--
-- Name: LogoProofMockups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LogoProofMockups" (
    id integer NOT NULL,
    "imagesId" integer NOT NULL,
    "logoProofId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleteAt" timestamp(3) without time zone
);


ALTER TABLE public."LogoProofMockups" OWNER TO postgres;

--
-- Name: LogoProofMockups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LogoProofMockups_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."LogoProofMockups_id_seq" OWNER TO postgres;

--
-- Name: LogoProofMockups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LogoProofMockups_id_seq" OWNED BY public."LogoProofMockups".id;


--
-- Name: LogoProof_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LogoProof_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."LogoProof_id_seq" OWNER TO postgres;

--
-- Name: LogoProof_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LogoProof_id_seq" OWNED BY public."LogoProof".id;


--
-- Name: LogoService; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LogoService" (
    id integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    "dueDate" timestamp(3) without time zone,
    "serviceTypeId" integer DEFAULT 3,
    "logoBriefingId" integer,
    "logoProofId" integer,
    "feedbackSended" boolean DEFAULT false,
    "logoFeedbackId" integer,
    status integer DEFAULT 1 NOT NULL
);


ALTER TABLE public."LogoService" OWNER TO postgres;

--
-- Name: LogoService_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LogoService_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."LogoService_id_seq" OWNER TO postgres;

--
-- Name: LogoService_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LogoService_id_seq" OWNED BY public."LogoService".id;


--
-- Name: Packages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Packages" (
    id integer NOT NULL,
    name text NOT NULL,
    price double precision NOT NULL,
    description text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    "dueDate" timestamp(3) without time zone,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Packages" OWNER TO postgres;

--
-- Name: PackagesServices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PackagesServices" (
    id integer NOT NULL,
    "packageId" integer NOT NULL,
    "serviceId" integer NOT NULL
);


ALTER TABLE public."PackagesServices" OWNER TO postgres;

--
-- Name: PackagesServices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PackagesServices_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PackagesServices_id_seq" OWNER TO postgres;

--
-- Name: PackagesServices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PackagesServices_id_seq" OWNED BY public."PackagesServices".id;


--
-- Name: Packages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Packages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Packages_id_seq" OWNER TO postgres;

--
-- Name: Packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Packages_id_seq" OWNED BY public."Packages".id;


--
-- Name: Payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Payments" (
    id integer NOT NULL,
    "clientId" integer NOT NULL,
    "companiesId" integer NOT NULL,
    value double precision NOT NULL,
    discount double precision,
    "voucherId" integer,
    status public."PaymentStatus" NOT NULL,
    "logGateway" jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    uuid text NOT NULL
);


ALTER TABLE public."Payments" OWNER TO postgres;

--
-- Name: PaymentsServices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PaymentsServices" (
    id integer NOT NULL,
    "paymentsId" integer NOT NULL,
    "serviceId" integer,
    "clientId" integer NOT NULL,
    "companiesId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "packagesId" integer
);


ALTER TABLE public."PaymentsServices" OWNER TO postgres;

--
-- Name: PaymentsServices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PaymentsServices_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PaymentsServices_id_seq" OWNER TO postgres;

--
-- Name: PaymentsServices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PaymentsServices_id_seq" OWNED BY public."PaymentsServices".id;


--
-- Name: Payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Payments_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Payments_id_seq" OWNER TO postgres;

--
-- Name: Payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Payments_id_seq" OWNED BY public."Payments".id;


--
-- Name: RoleType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RoleType" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."RoleType" OWNER TO postgres;

--
-- Name: RoleType_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RoleType_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."RoleType_id_seq" OWNER TO postgres;

--
-- Name: RoleType_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RoleType_id_seq" OWNED BY public."RoleType".id;


--
-- Name: Service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Service" (
    id integer NOT NULL,
    name text NOT NULL,
    price double precision NOT NULL,
    description text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    "serviceTypeId" integer NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "modelServiceId" integer
);


ALTER TABLE public."Service" OWNER TO postgres;

--
-- Name: ServiceType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ServiceType" (
    id integer NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ServiceType" OWNER TO postgres;

--
-- Name: ServiceTypeChoose; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ServiceTypeChoose" (
    id integer NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "serviceTypeId" integer
);


ALTER TABLE public."ServiceTypeChoose" OWNER TO postgres;

--
-- Name: ServiceTypeChoose_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ServiceTypeChoose_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ServiceTypeChoose_id_seq" OWNER TO postgres;

--
-- Name: ServiceTypeChoose_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ServiceTypeChoose_id_seq" OWNED BY public."ServiceTypeChoose".id;


--
-- Name: ServiceType_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ServiceType_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ServiceType_id_seq" OWNER TO postgres;

--
-- Name: ServiceType_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ServiceType_id_seq" OWNED BY public."ServiceType".id;


--
-- Name: Service_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Service_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Service_id_seq" OWNER TO postgres;

--
-- Name: Service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Service_id_seq" OWNED BY public."Service".id;


--
-- Name: SiteBriefing; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SiteBriefing" (
    id integer NOT NULL,
    url text,
    "references" jsonb,
    logo text,
    "contactData" text,
    "socialMidia" text,
    host text,
    "hostLogin" text,
    "hostPass" text,
    "briefingId" integer,
    colors jsonb,
    "urlLogin" text,
    "urlPass" text,
    "urlName" text
);


ALTER TABLE public."SiteBriefing" OWNER TO postgres;

--
-- Name: SiteBriefing_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SiteBriefing_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SiteBriefing_id_seq" OWNER TO postgres;

--
-- Name: SiteBriefing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SiteBriefing_id_seq" OWNED BY public."SiteBriefing".id;


--
-- Name: SiteContratedItems; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SiteContratedItems" (
    id integer NOT NULL,
    "contratedServiceId" integer NOT NULL,
    "siteServiceId" integer NOT NULL
);


ALTER TABLE public."SiteContratedItems" OWNER TO postgres;

--
-- Name: SiteContratedItems_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SiteContratedItems_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SiteContratedItems_id_seq" OWNER TO postgres;

--
-- Name: SiteContratedItems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SiteContratedItems_id_seq" OWNED BY public."SiteContratedItems".id;


--
-- Name: SiteLayoutFinished; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SiteLayoutFinished" (
    id integer NOT NULL,
    "isApproved" boolean,
    "layoutId" integer,
    "refuseReason" text
);


ALTER TABLE public."SiteLayoutFinished" OWNER TO postgres;

--
-- Name: SiteLayoutFinished_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SiteLayoutFinished_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SiteLayoutFinished_id_seq" OWNER TO postgres;

--
-- Name: SiteLayoutFinished_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SiteLayoutFinished_id_seq" OWNED BY public."SiteLayoutFinished".id;


--
-- Name: SiteLayoutSelected; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SiteLayoutSelected" (
    id integer NOT NULL,
    "layoutId" integer
);


ALTER TABLE public."SiteLayoutSelected" OWNER TO postgres;

--
-- Name: SiteLayoutSelected_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SiteLayoutSelected_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SiteLayoutSelected_id_seq" OWNER TO postgres;

--
-- Name: SiteLayoutSelected_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SiteLayoutSelected_id_seq" OWNED BY public."SiteLayoutSelected".id;


--
-- Name: SiteLayoutsBase; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SiteLayoutsBase" (
    id integer NOT NULL,
    name text NOT NULL,
    "layoutId" integer NOT NULL,
    "siteServiceId" integer
);


ALTER TABLE public."SiteLayoutsBase" OWNER TO postgres;

--
-- Name: SiteLayoutsBase_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SiteLayoutsBase_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SiteLayoutsBase_id_seq" OWNER TO postgres;

--
-- Name: SiteLayoutsBase_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SiteLayoutsBase_id_seq" OWNED BY public."SiteLayoutsBase".id;


--
-- Name: SiteService; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SiteService" (
    id integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    "dueDate" timestamp(3) without time zone,
    "serviceTypeId" integer DEFAULT 1,
    "siteBriefingId" integer,
    "siteLayoutFinishedId" integer,
    "siteLayoutSelectedId" integer,
    "isPublished" boolean,
    status integer DEFAULT 1 NOT NULL
);


ALTER TABLE public."SiteService" OWNER TO postgres;

--
-- Name: SiteService_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SiteService_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SiteService_id_seq" OWNER TO postgres;

--
-- Name: SiteService_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SiteService_id_seq" OWNED BY public."SiteService".id;


--
-- Name: SocialBriefing; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SocialBriefing" (
    id integer NOT NULL,
    "networkType" public."NetworkTypes" NOT NULL,
    "serviceType" public."SocialServiceTypes" NOT NULL,
    "imageBase" public."SocialImageBase" NOT NULL,
    "materialQuant" public."SocialMaterialQuant" NOT NULL,
    "daysHours" text NOT NULL,
    "mediaFormat" public."MediaFormat" NOT NULL
);


ALTER TABLE public."SocialBriefing" OWNER TO postgres;

--
-- Name: SocialBriefing_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SocialBriefing_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SocialBriefing_id_seq" OWNER TO postgres;

--
-- Name: SocialBriefing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SocialBriefing_id_seq" OWNED BY public."SocialBriefing".id;


--
-- Name: SocialContratedItems; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SocialContratedItems" (
    id integer NOT NULL,
    "contratedServiceId" integer NOT NULL,
    "socialServiceId" integer NOT NULL
);


ALTER TABLE public."SocialContratedItems" OWNER TO postgres;

--
-- Name: SocialContratedItems_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SocialContratedItems_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SocialContratedItems_id_seq" OWNER TO postgres;

--
-- Name: SocialContratedItems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SocialContratedItems_id_seq" OWNED BY public."SocialContratedItems".id;


--
-- Name: SocialFeedShow; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SocialFeedShow" (
    id integer NOT NULL,
    text text NOT NULL,
    type public."SocialFeedShowType" NOT NULL,
    approved boolean,
    "reasonRefuse" text,
    "socialShowId" integer,
    "imagesId" integer
);


ALTER TABLE public."SocialFeedShow" OWNER TO postgres;

--
-- Name: SocialFeedShow_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SocialFeedShow_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SocialFeedShow_id_seq" OWNER TO postgres;

--
-- Name: SocialFeedShow_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SocialFeedShow_id_seq" OWNED BY public."SocialFeedShow".id;


--
-- Name: SocialService; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SocialService" (
    id integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    "dueDate" timestamp(3) without time zone,
    "serviceTypeId" integer DEFAULT 2,
    "socialBriefingId" integer,
    "socialShowId" integer,
    status integer DEFAULT 1 NOT NULL,
    "actualMonth" integer DEFAULT 1 NOT NULL
);


ALTER TABLE public."SocialService" OWNER TO postgres;

--
-- Name: SocialService_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SocialService_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SocialService_id_seq" OWNER TO postgres;

--
-- Name: SocialService_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SocialService_id_seq" OWNED BY public."SocialService".id;


--
-- Name: SocialShow; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SocialShow" (
    id integer NOT NULL,
    "allApproved" boolean,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    "isRefused" boolean DEFAULT false NOT NULL,
    "isSendedByClient" boolean
);


ALTER TABLE public."SocialShow" OWNER TO postgres;

--
-- Name: SocialShow_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SocialShow_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SocialShow_id_seq" OWNER TO postgres;

--
-- Name: SocialShow_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SocialShow_id_seq" OWNED BY public."SocialShow".id;


--
-- Name: Tables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Tables" (
    id integer NOT NULL,
    "tabName" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone
);


ALTER TABLE public."Tables" OWNER TO postgres;

--
-- Name: Tables_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Tables_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Tables_id_seq" OWNER TO postgres;

--
-- Name: Tables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Tables_id_seq" OWNED BY public."Tables".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone,
    "deletedAt" timestamp(3) without time zone,
    notification boolean DEFAULT true NOT NULL,
    "firebaseToken" text NOT NULL,
    "roleTypeId" integer DEFAULT 1 NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."User_id_seq" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[]
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- Name: decrypted_secrets; Type: VIEW; Schema: vault; Owner: supabase_admin
--

CREATE VIEW vault.decrypted_secrets AS
 SELECT secrets.id,
    secrets.name,
    secrets.description,
    secrets.secret,
        CASE
            WHEN (secrets.secret IS NULL) THEN NULL::text
            ELSE
            CASE
                WHEN (secrets.key_id IS NULL) THEN NULL::text
                ELSE convert_from(pgsodium.crypto_aead_det_decrypt(decode(secrets.secret, 'base64'::text), convert_to(((((secrets.id)::text || secrets.description) || (secrets.created_at)::text) || (secrets.updated_at)::text), 'utf8'::name), secrets.key_id, secrets.nonce), 'utf8'::name)
            END
        END AS decrypted_secret,
    secrets.key_id,
    secrets.nonce,
    secrets.created_at,
    secrets.updated_at
   FROM vault.secrets;


ALTER TABLE vault.decrypted_secrets OWNER TO supabase_admin;

--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Name: Archives id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Archives" ALTER COLUMN id SET DEFAULT nextval('public."Archives_id_seq"'::regclass);


--
-- Name: Cards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Cards" ALTER COLUMN id SET DEFAULT nextval('public."Cards_id_seq"'::regclass);


--
-- Name: Client id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Client" ALTER COLUMN id SET DEFAULT nextval('public."Client_id_seq"'::regclass);


--
-- Name: Companies id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Companies" ALTER COLUMN id SET DEFAULT nextval('public."Companies_id_seq"'::regclass);


--
-- Name: ContratedService id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ContratedService" ALTER COLUMN id SET DEFAULT nextval('public."ContratedService_id_seq"'::regclass);


--
-- Name: Employee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee" ALTER COLUMN id SET DEFAULT nextval('public."Employee_id_seq"'::regclass);


--
-- Name: Errors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Errors" ALTER COLUMN id SET DEFAULT nextval('public."Errors_id_seq"'::regclass);


--
-- Name: Images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Images" ALTER COLUMN id SET DEFAULT nextval('public."Images_id_seq"'::regclass);


--
-- Name: Lead id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lead" ALTER COLUMN id SET DEFAULT nextval('public."Lead_id_seq"'::regclass);


--
-- Name: LogoArchives id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoArchives" ALTER COLUMN id SET DEFAULT nextval('public."LogoArchives_id_seq"'::regclass);


--
-- Name: LogoBriefing id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoBriefing" ALTER COLUMN id SET DEFAULT nextval('public."LogoBriefing_id_seq"'::regclass);


--
-- Name: LogoContratedItems id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoContratedItems" ALTER COLUMN id SET DEFAULT nextval('public."LogoContratedItems_id_seq"'::regclass);


--
-- Name: LogoFeedback id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoFeedback" ALTER COLUMN id SET DEFAULT nextval('public."LogoFeedback_id_seq"'::regclass);


--
-- Name: LogoProof id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoProof" ALTER COLUMN id SET DEFAULT nextval('public."LogoProof_id_seq"'::regclass);


--
-- Name: LogoProofMockups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoProofMockups" ALTER COLUMN id SET DEFAULT nextval('public."LogoProofMockups_id_seq"'::regclass);


--
-- Name: LogoService id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoService" ALTER COLUMN id SET DEFAULT nextval('public."LogoService_id_seq"'::regclass);


--
-- Name: Packages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Packages" ALTER COLUMN id SET DEFAULT nextval('public."Packages_id_seq"'::regclass);


--
-- Name: PackagesServices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PackagesServices" ALTER COLUMN id SET DEFAULT nextval('public."PackagesServices_id_seq"'::regclass);


--
-- Name: Payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payments" ALTER COLUMN id SET DEFAULT nextval('public."Payments_id_seq"'::regclass);


--
-- Name: PaymentsServices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentsServices" ALTER COLUMN id SET DEFAULT nextval('public."PaymentsServices_id_seq"'::regclass);


--
-- Name: RoleType id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoleType" ALTER COLUMN id SET DEFAULT nextval('public."RoleType_id_seq"'::regclass);


--
-- Name: Service id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Service" ALTER COLUMN id SET DEFAULT nextval('public."Service_id_seq"'::regclass);


--
-- Name: ServiceType id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceType" ALTER COLUMN id SET DEFAULT nextval('public."ServiceType_id_seq"'::regclass);


--
-- Name: ServiceTypeChoose id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceTypeChoose" ALTER COLUMN id SET DEFAULT nextval('public."ServiceTypeChoose_id_seq"'::regclass);


--
-- Name: SiteBriefing id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteBriefing" ALTER COLUMN id SET DEFAULT nextval('public."SiteBriefing_id_seq"'::regclass);


--
-- Name: SiteContratedItems id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteContratedItems" ALTER COLUMN id SET DEFAULT nextval('public."SiteContratedItems_id_seq"'::regclass);


--
-- Name: SiteLayoutFinished id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteLayoutFinished" ALTER COLUMN id SET DEFAULT nextval('public."SiteLayoutFinished_id_seq"'::regclass);


--
-- Name: SiteLayoutSelected id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteLayoutSelected" ALTER COLUMN id SET DEFAULT nextval('public."SiteLayoutSelected_id_seq"'::regclass);


--
-- Name: SiteLayoutsBase id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteLayoutsBase" ALTER COLUMN id SET DEFAULT nextval('public."SiteLayoutsBase_id_seq"'::regclass);


--
-- Name: SiteService id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteService" ALTER COLUMN id SET DEFAULT nextval('public."SiteService_id_seq"'::regclass);


--
-- Name: SocialBriefing id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialBriefing" ALTER COLUMN id SET DEFAULT nextval('public."SocialBriefing_id_seq"'::regclass);


--
-- Name: SocialContratedItems id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialContratedItems" ALTER COLUMN id SET DEFAULT nextval('public."SocialContratedItems_id_seq"'::regclass);


--
-- Name: SocialFeedShow id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialFeedShow" ALTER COLUMN id SET DEFAULT nextval('public."SocialFeedShow_id_seq"'::regclass);


--
-- Name: SocialService id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialService" ALTER COLUMN id SET DEFAULT nextval('public."SocialService_id_seq"'::regclass);


--
-- Name: SocialShow id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialShow" ALTER COLUMN id SET DEFAULT nextval('public."SocialShow_id_seq"'::regclass);


--
-- Name: Tables id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tables" ALTER COLUMN id SET DEFAULT nextval('public."Tables_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.
COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM '$$PATH$$/4297.dat';

--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method) FROM stdin;
\.
COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method) FROM '$$PATH$$/4311.dat';

--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.identities (id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at) FROM stdin;
\.
COPY auth.identities (id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at) FROM '$$PATH$$/4302.dat';

--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.
COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM '$$PATH$$/4296.dat';

--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.
COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM '$$PATH$$/4306.dat';

--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address) FROM stdin;
\.
COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address) FROM '$$PATH$$/4305.dat';

--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret) FROM stdin;
\.
COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret) FROM '$$PATH$$/4304.dat';

--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.
COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM '$$PATH$$/4295.dat';

--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at) FROM stdin;
\.
COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at) FROM '$$PATH$$/4309.dat';

--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, from_ip_address, created_at, updated_at) FROM stdin;
\.
COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, from_ip_address, created_at, updated_at) FROM '$$PATH$$/4310.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.schema_migrations (version) FROM stdin;
\.
COPY auth.schema_migrations (version) FROM '$$PATH$$/4298.dat';

--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after) FROM stdin;
\.
COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after) FROM '$$PATH$$/4303.dat';

--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.
COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM '$$PATH$$/4308.dat';

--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at) FROM stdin;
\.
COPY auth.sso_providers (id, resource_id, created_at, updated_at) FROM '$$PATH$$/4307.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at) FROM stdin;
\.
COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at) FROM '$$PATH$$/4293.dat';

--
-- Data for Name: key; Type: TABLE DATA; Schema: pgsodium; Owner: supabase_admin
--

COPY pgsodium.key (id, status, created, expires, key_type, key_id, key_context, name, associated_data, raw_key, raw_key_nonce, parent_key, comment, user_data) FROM stdin;
\.
COPY pgsodium.key (id, status, created, expires, key_type, key_id, key_context, name, associated_data, raw_key, raw_key_nonce, parent_key, comment, user_data) FROM '$$PATH$$/3787.dat';

--
-- Data for Name: Archives; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Archives" (id, url, "companiesId", "createdAt", "updatedAt", "siteBriefingId") FROM stdin;
\.
COPY public."Archives" (id, url, "companiesId", "createdAt", "updatedAt", "siteBriefingId") FROM '$$PATH$$/4383.dat';

--
-- Data for Name: Cards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Cards" (id, "nameCard", type, description, "publishedAt", steps, "typeCard", "whoDoing", "clientId", "dueDate", "createdAt", "updatedAt", "companiesId") FROM stdin;
\.
COPY public."Cards" (id, "nameCard", type, description, "publishedAt", steps, "typeCard", "whoDoing", "clientId", "dueDate", "createdAt", "updatedAt", "companiesId") FROM '$$PATH$$/4313.dat';

--
-- Data for Name: Client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Client" (id, name, document, "documentType", phone, cep, "costumerId", "createdAt", "updatedAt", "userId", "companiesId") FROM stdin;
\.
COPY public."Client" (id, name, document, "documentType", phone, cep, "costumerId", "createdAt", "updatedAt", "userId", "companiesId") FROM '$$PATH$$/4315.dat';

--
-- Data for Name: Companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Companies" (id, "companyName", document, "documentType", "createdAt", "updatedAt", "ownerId") FROM stdin;
\.
COPY public."Companies" (id, "companyName", document, "documentType", "createdAt", "updatedAt", "ownerId") FROM '$$PATH$$/4317.dat';

--
-- Data for Name: ContratedService; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ContratedService" (id, "companiesId") FROM stdin;
\.
COPY public."ContratedService" (id, "companiesId") FROM '$$PATH$$/4319.dat';

--
-- Data for Name: Employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Employee" (id, name, "documentType", document, phone, "createdAt", "updatedAt", "userId") FROM stdin;
\.
COPY public."Employee" (id, name, "documentType", document, phone, "createdAt", "updatedAt", "userId") FROM '$$PATH$$/4321.dat';

--
-- Data for Name: Errors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Errors" (id, "errorCode", message, "userId", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Errors" (id, "errorCode", message, "userId", "createdAt", "updatedAt") FROM '$$PATH$$/4323.dat';

--
-- Data for Name: Images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Images" (id, url, title, author, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Images" (id, url, title, author, "createdAt", "updatedAt") FROM '$$PATH$$/4325.dat';

--
-- Data for Name: Lead; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Lead" (id, name, email, phone, "createdAt", "updatedAt", "subscribeAt") FROM stdin;
\.
COPY public."Lead" (id, name, email, phone, "createdAt", "updatedAt", "subscribeAt") FROM '$$PATH$$/4327.dat';

--
-- Data for Name: LogoArchives; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LogoArchives" (id, name, type, url, "previewId", "createdAt", "updatedAt", "logoServiceId") FROM stdin;
\.
COPY public."LogoArchives" (id, name, type, url, "previewId", "createdAt", "updatedAt", "logoServiceId") FROM '$$PATH$$/4337.dat';

--
-- Data for Name: LogoBriefing; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LogoBriefing" (id, format, cores, typography, especification, description, "references", titlefirst, titlesecond) FROM stdin;
\.
COPY public."LogoBriefing" (id, format, cores, typography, especification, description, "references", titlefirst, titlesecond) FROM '$$PATH$$/4329.dat';

--
-- Data for Name: LogoContratedItems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LogoContratedItems" (id, "contratedServiceId", "logoServiceId") FROM stdin;
\.
COPY public."LogoContratedItems" (id, "contratedServiceId", "logoServiceId") FROM '$$PATH$$/4331.dat';

--
-- Data for Name: LogoFeedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LogoFeedback" (id, stars, comments, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."LogoFeedback" (id, stars, comments, "createdAt", "updatedAt") FROM '$$PATH$$/4335.dat';

--
-- Data for Name: LogoProof; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LogoProof" (id, "isApproved", "reasonRefuse", "imagesId", "userSended") FROM stdin;
\.
COPY public."LogoProof" (id, "isApproved", "reasonRefuse", "imagesId", "userSended") FROM '$$PATH$$/4339.dat';

--
-- Data for Name: LogoProofMockups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LogoProofMockups" (id, "imagesId", "logoProofId", "createdAt", "deleteAt") FROM stdin;
\.
COPY public."LogoProofMockups" (id, "imagesId", "logoProofId", "createdAt", "deleteAt") FROM '$$PATH$$/4341.dat';

--
-- Data for Name: LogoService; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LogoService" (id, "createdAt", "updatedAt", "dueDate", "serviceTypeId", "logoBriefingId", "logoProofId", "feedbackSended", "logoFeedbackId", status) FROM stdin;
\.
COPY public."LogoService" (id, "createdAt", "updatedAt", "dueDate", "serviceTypeId", "logoBriefingId", "logoProofId", "feedbackSended", "logoFeedbackId", status) FROM '$$PATH$$/4333.dat';

--
-- Data for Name: Packages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Packages" (id, name, price, description, "createdAt", "updatedAt", "dueDate", "deletedAt") FROM stdin;
\.
COPY public."Packages" (id, name, price, description, "createdAt", "updatedAt", "dueDate", "deletedAt") FROM '$$PATH$$/4343.dat';

--
-- Data for Name: PackagesServices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PackagesServices" (id, "packageId", "serviceId") FROM stdin;
\.
COPY public."PackagesServices" (id, "packageId", "serviceId") FROM '$$PATH$$/4345.dat';

--
-- Data for Name: Payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Payments" (id, "clientId", "companiesId", value, discount, "voucherId", status, "logGateway", "createdAt", "updatedAt", uuid) FROM stdin;
\.
COPY public."Payments" (id, "clientId", "companiesId", value, discount, "voucherId", status, "logGateway", "createdAt", "updatedAt", uuid) FROM '$$PATH$$/4347.dat';

--
-- Data for Name: PaymentsServices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PaymentsServices" (id, "paymentsId", "serviceId", "clientId", "companiesId", "createdAt", "packagesId") FROM stdin;
\.
COPY public."PaymentsServices" (id, "paymentsId", "serviceId", "clientId", "companiesId", "createdAt", "packagesId") FROM '$$PATH$$/4349.dat';

--
-- Data for Name: RoleType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RoleType" (id, name) FROM stdin;
\.
COPY public."RoleType" (id, name) FROM '$$PATH$$/4351.dat';

--
-- Data for Name: Service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Service" (id, name, price, description, "createdAt", "updatedAt", "serviceTypeId", "deletedAt", "modelServiceId") FROM stdin;
\.
COPY public."Service" (id, name, price, description, "createdAt", "updatedAt", "serviceTypeId", "deletedAt", "modelServiceId") FROM '$$PATH$$/4353.dat';

--
-- Data for Name: ServiceType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ServiceType" (id, name, "createdAt") FROM stdin;
\.
COPY public."ServiceType" (id, name, "createdAt") FROM '$$PATH$$/4355.dat';

--
-- Data for Name: ServiceTypeChoose; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ServiceTypeChoose" (id, name, "createdAt", "serviceTypeId") FROM stdin;
\.
COPY public."ServiceTypeChoose" (id, name, "createdAt", "serviceTypeId") FROM '$$PATH$$/4385.dat';

--
-- Data for Name: SiteBriefing; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SiteBriefing" (id, url, "references", logo, "contactData", "socialMidia", host, "hostLogin", "hostPass", "briefingId", colors, "urlLogin", "urlPass", "urlName") FROM stdin;
\.
COPY public."SiteBriefing" (id, url, "references", logo, "contactData", "socialMidia", host, "hostLogin", "hostPass", "briefingId", colors, "urlLogin", "urlPass", "urlName") FROM '$$PATH$$/4357.dat';

--
-- Data for Name: SiteContratedItems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SiteContratedItems" (id, "contratedServiceId", "siteServiceId") FROM stdin;
\.
COPY public."SiteContratedItems" (id, "contratedServiceId", "siteServiceId") FROM '$$PATH$$/4359.dat';

--
-- Data for Name: SiteLayoutFinished; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SiteLayoutFinished" (id, "isApproved", "layoutId", "refuseReason") FROM stdin;
\.
COPY public."SiteLayoutFinished" (id, "isApproved", "layoutId", "refuseReason") FROM '$$PATH$$/4367.dat';

--
-- Data for Name: SiteLayoutSelected; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SiteLayoutSelected" (id, "layoutId") FROM stdin;
\.
COPY public."SiteLayoutSelected" (id, "layoutId") FROM '$$PATH$$/4365.dat';

--
-- Data for Name: SiteLayoutsBase; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SiteLayoutsBase" (id, name, "layoutId", "siteServiceId") FROM stdin;
\.
COPY public."SiteLayoutsBase" (id, name, "layoutId", "siteServiceId") FROM '$$PATH$$/4363.dat';

--
-- Data for Name: SiteService; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SiteService" (id, "createdAt", "updatedAt", "dueDate", "serviceTypeId", "siteBriefingId", "siteLayoutFinishedId", "siteLayoutSelectedId", "isPublished", status) FROM stdin;
\.
COPY public."SiteService" (id, "createdAt", "updatedAt", "dueDate", "serviceTypeId", "siteBriefingId", "siteLayoutFinishedId", "siteLayoutSelectedId", "isPublished", status) FROM '$$PATH$$/4361.dat';

--
-- Data for Name: SocialBriefing; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SocialBriefing" (id, "networkType", "serviceType", "imageBase", "materialQuant", "daysHours", "mediaFormat") FROM stdin;
\.
COPY public."SocialBriefing" (id, "networkType", "serviceType", "imageBase", "materialQuant", "daysHours", "mediaFormat") FROM '$$PATH$$/4369.dat';

--
-- Data for Name: SocialContratedItems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SocialContratedItems" (id, "contratedServiceId", "socialServiceId") FROM stdin;
\.
COPY public."SocialContratedItems" (id, "contratedServiceId", "socialServiceId") FROM '$$PATH$$/4371.dat';

--
-- Data for Name: SocialFeedShow; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SocialFeedShow" (id, text, type, approved, "reasonRefuse", "socialShowId", "imagesId") FROM stdin;
\.
COPY public."SocialFeedShow" (id, text, type, approved, "reasonRefuse", "socialShowId", "imagesId") FROM '$$PATH$$/4377.dat';

--
-- Data for Name: SocialService; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SocialService" (id, "createdAt", "updatedAt", "dueDate", "serviceTypeId", "socialBriefingId", "socialShowId", status, "actualMonth") FROM stdin;
\.
COPY public."SocialService" (id, "createdAt", "updatedAt", "dueDate", "serviceTypeId", "socialBriefingId", "socialShowId", status, "actualMonth") FROM '$$PATH$$/4373.dat';

--
-- Data for Name: SocialShow; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SocialShow" (id, "allApproved", "createdAt", "updatedAt", "isRefused", "isSendedByClient") FROM stdin;
\.
COPY public."SocialShow" (id, "allApproved", "createdAt", "updatedAt", "isRefused", "isSendedByClient") FROM '$$PATH$$/4375.dat';

--
-- Data for Name: Tables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Tables" (id, "tabName", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Tables" (id, "tabName", "createdAt", "updatedAt") FROM '$$PATH$$/4379.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, email, password, "createdAt", "updatedAt", "deletedAt", notification, "firebaseToken", "roleTypeId") FROM stdin;
\.
COPY public."User" (id, email, password, "createdAt", "updatedAt", "deletedAt", notification, "firebaseToken", "roleTypeId") FROM '$$PATH$$/4381.dat';

--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types) FROM stdin;
\.
COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types) FROM '$$PATH$$/4299.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
\.
COPY storage.migrations (id, name, hash, executed_at) FROM '$$PATH$$/4301.dat';

--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version) FROM stdin;
\.
COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version) FROM '$$PATH$$/4300.dat';

--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.
COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM '$$PATH$$/3789.dat';

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- Name: key_key_id_seq; Type: SEQUENCE SET; Schema: pgsodium; Owner: supabase_admin
--

SELECT pg_catalog.setval('pgsodium.key_key_id_seq', 1, false);


--
-- Name: Archives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Archives_id_seq"', 44, true);


--
-- Name: Cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Cards_id_seq"', 1, false);


--
-- Name: Client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Client_id_seq"', 33, true);


--
-- Name: Companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Companies_id_seq"', 18, true);


--
-- Name: ContratedService_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ContratedService_id_seq"', 7, true);


--
-- Name: Employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Employee_id_seq"', 2, true);


--
-- Name: Errors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Errors_id_seq"', 1, false);


--
-- Name: Images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Images_id_seq"', 48, true);


--
-- Name: Lead_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Lead_id_seq"', 1, false);


--
-- Name: LogoArchives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LogoArchives_id_seq"', 11, true);


--
-- Name: LogoBriefing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LogoBriefing_id_seq"', 8, true);


--
-- Name: LogoContratedItems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LogoContratedItems_id_seq"', 8, true);


--
-- Name: LogoFeedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LogoFeedback_id_seq"', 1, false);


--
-- Name: LogoProofMockups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LogoProofMockups_id_seq"', 9, true);


--
-- Name: LogoProof_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LogoProof_id_seq"', 4, true);


--
-- Name: LogoService_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LogoService_id_seq"', 8, true);


--
-- Name: PackagesServices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PackagesServices_id_seq"', 18, true);


--
-- Name: Packages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Packages_id_seq"', 9, true);


--
-- Name: PaymentsServices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PaymentsServices_id_seq"', 21, true);


--
-- Name: Payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Payments_id_seq"', 21, true);


--
-- Name: RoleType_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RoleType_id_seq"', 1, false);


--
-- Name: ServiceTypeChoose_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ServiceTypeChoose_id_seq"', 1, false);


--
-- Name: ServiceType_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ServiceType_id_seq"', 1, false);


--
-- Name: Service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Service_id_seq"', 10, true);


--
-- Name: SiteBriefing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SiteBriefing_id_seq"', 5, true);


--
-- Name: SiteContratedItems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SiteContratedItems_id_seq"', 5, true);


--
-- Name: SiteLayoutFinished_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SiteLayoutFinished_id_seq"', 3, true);


--
-- Name: SiteLayoutSelected_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SiteLayoutSelected_id_seq"', 4, true);


--
-- Name: SiteLayoutsBase_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SiteLayoutsBase_id_seq"', 4, true);


--
-- Name: SiteService_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SiteService_id_seq"', 5, true);


--
-- Name: SocialBriefing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SocialBriefing_id_seq"', 5, true);


--
-- Name: SocialContratedItems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SocialContratedItems_id_seq"', 2, true);


--
-- Name: SocialFeedShow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SocialFeedShow_id_seq"', 1, false);


--
-- Name: SocialService_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SocialService_id_seq"', 2, true);


--
-- Name: SocialShow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SocialShow_id_seq"', 1, false);


--
-- Name: Tables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Tables_id_seq"', 1, false);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_id_seq"', 37, true);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (provider, id);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: Archives Archives_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Archives"
    ADD CONSTRAINT "Archives_pkey" PRIMARY KEY (id);


--
-- Name: Cards Cards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Cards"
    ADD CONSTRAINT "Cards_pkey" PRIMARY KEY (id);


--
-- Name: Client Client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_pkey" PRIMARY KEY (id);


--
-- Name: Companies Companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Companies"
    ADD CONSTRAINT "Companies_pkey" PRIMARY KEY (id);


--
-- Name: ContratedService ContratedService_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ContratedService"
    ADD CONSTRAINT "ContratedService_pkey" PRIMARY KEY (id);


--
-- Name: Employee Employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_pkey" PRIMARY KEY (id);


--
-- Name: Errors Errors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Errors"
    ADD CONSTRAINT "Errors_pkey" PRIMARY KEY (id);


--
-- Name: Images Images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Images"
    ADD CONSTRAINT "Images_pkey" PRIMARY KEY (id);


--
-- Name: Lead Lead_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lead"
    ADD CONSTRAINT "Lead_pkey" PRIMARY KEY (id);


--
-- Name: LogoArchives LogoArchives_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoArchives"
    ADD CONSTRAINT "LogoArchives_pkey" PRIMARY KEY (id);


--
-- Name: LogoBriefing LogoBriefing_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoBriefing"
    ADD CONSTRAINT "LogoBriefing_pkey" PRIMARY KEY (id);


--
-- Name: LogoContratedItems LogoContratedItems_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoContratedItems"
    ADD CONSTRAINT "LogoContratedItems_pkey" PRIMARY KEY (id);


--
-- Name: LogoFeedback LogoFeedback_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoFeedback"
    ADD CONSTRAINT "LogoFeedback_pkey" PRIMARY KEY (id);


--
-- Name: LogoProofMockups LogoProofMockups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoProofMockups"
    ADD CONSTRAINT "LogoProofMockups_pkey" PRIMARY KEY (id);


--
-- Name: LogoProof LogoProof_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoProof"
    ADD CONSTRAINT "LogoProof_pkey" PRIMARY KEY (id);


--
-- Name: LogoService LogoService_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoService"
    ADD CONSTRAINT "LogoService_pkey" PRIMARY KEY (id);


--
-- Name: PackagesServices PackagesServices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PackagesServices"
    ADD CONSTRAINT "PackagesServices_pkey" PRIMARY KEY (id);


--
-- Name: Packages Packages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Packages"
    ADD CONSTRAINT "Packages_pkey" PRIMARY KEY (id);


--
-- Name: PaymentsServices PaymentsServices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentsServices"
    ADD CONSTRAINT "PaymentsServices_pkey" PRIMARY KEY (id);


--
-- Name: Payments Payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payments"
    ADD CONSTRAINT "Payments_pkey" PRIMARY KEY (id);


--
-- Name: RoleType RoleType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoleType"
    ADD CONSTRAINT "RoleType_pkey" PRIMARY KEY (id);


--
-- Name: ServiceTypeChoose ServiceTypeChoose_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceTypeChoose"
    ADD CONSTRAINT "ServiceTypeChoose_pkey" PRIMARY KEY (id);


--
-- Name: ServiceType ServiceType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceType"
    ADD CONSTRAINT "ServiceType_pkey" PRIMARY KEY (id);


--
-- Name: Service Service_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Service"
    ADD CONSTRAINT "Service_pkey" PRIMARY KEY (id);


--
-- Name: SiteBriefing SiteBriefing_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteBriefing"
    ADD CONSTRAINT "SiteBriefing_pkey" PRIMARY KEY (id);


--
-- Name: SiteContratedItems SiteContratedItems_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteContratedItems"
    ADD CONSTRAINT "SiteContratedItems_pkey" PRIMARY KEY (id);


--
-- Name: SiteLayoutFinished SiteLayoutFinished_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteLayoutFinished"
    ADD CONSTRAINT "SiteLayoutFinished_pkey" PRIMARY KEY (id);


--
-- Name: SiteLayoutSelected SiteLayoutSelected_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteLayoutSelected"
    ADD CONSTRAINT "SiteLayoutSelected_pkey" PRIMARY KEY (id);


--
-- Name: SiteLayoutsBase SiteLayoutsBase_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteLayoutsBase"
    ADD CONSTRAINT "SiteLayoutsBase_pkey" PRIMARY KEY (id);


--
-- Name: SiteService SiteService_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteService"
    ADD CONSTRAINT "SiteService_pkey" PRIMARY KEY (id);


--
-- Name: SocialBriefing SocialBriefing_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialBriefing"
    ADD CONSTRAINT "SocialBriefing_pkey" PRIMARY KEY (id);


--
-- Name: SocialContratedItems SocialContratedItems_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialContratedItems"
    ADD CONSTRAINT "SocialContratedItems_pkey" PRIMARY KEY (id);


--
-- Name: SocialFeedShow SocialFeedShow_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialFeedShow"
    ADD CONSTRAINT "SocialFeedShow_pkey" PRIMARY KEY (id);


--
-- Name: SocialService SocialService_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialService"
    ADD CONSTRAINT "SocialService_pkey" PRIMARY KEY (id);


--
-- Name: SocialShow SocialShow_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialShow"
    ADD CONSTRAINT "SocialShow_pkey" PRIMARY KEY (id);


--
-- Name: Tables Tables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tables"
    ADD CONSTRAINT "Tables_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: Client_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Client_userId_key" ON public."Client" USING btree ("userId");


--
-- Name: Companies_document_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Companies_document_key" ON public."Companies" USING btree (document);


--
-- Name: ContratedService_companiesId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ContratedService_companiesId_key" ON public."ContratedService" USING btree ("companiesId");


--
-- Name: Lead_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Lead_email_key" ON public."Lead" USING btree (email);


--
-- Name: Payments_uuid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Payments_uuid_key" ON public."Payments" USING btree (uuid);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: Archives Archives_companiesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Archives"
    ADD CONSTRAINT "Archives_companiesId_fkey" FOREIGN KEY ("companiesId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Archives Archives_siteBriefingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Archives"
    ADD CONSTRAINT "Archives_siteBriefingId_fkey" FOREIGN KEY ("siteBriefingId") REFERENCES public."SiteBriefing"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Cards Cards_companiesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Cards"
    ADD CONSTRAINT "Cards_companiesId_fkey" FOREIGN KEY ("companiesId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Cards Cards_typeCard_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Cards"
    ADD CONSTRAINT "Cards_typeCard_fkey" FOREIGN KEY ("typeCard") REFERENCES public."Tables"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Cards Cards_whoDoing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Cards"
    ADD CONSTRAINT "Cards_whoDoing_fkey" FOREIGN KEY ("whoDoing") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Client Client_companiesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_companiesId_fkey" FOREIGN KEY ("companiesId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Client Client_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Companies Companies_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Companies"
    ADD CONSTRAINT "Companies_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ContratedService ContratedService_companiesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ContratedService"
    ADD CONSTRAINT "ContratedService_companiesId_fkey" FOREIGN KEY ("companiesId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Employee Employee_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Errors Errors_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Errors"
    ADD CONSTRAINT "Errors_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LogoArchives LogoArchives_logoServiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoArchives"
    ADD CONSTRAINT "LogoArchives_logoServiceId_fkey" FOREIGN KEY ("logoServiceId") REFERENCES public."LogoService"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LogoArchives LogoArchives_previewId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoArchives"
    ADD CONSTRAINT "LogoArchives_previewId_fkey" FOREIGN KEY ("previewId") REFERENCES public."Images"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LogoContratedItems LogoContratedItems_contratedServiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoContratedItems"
    ADD CONSTRAINT "LogoContratedItems_contratedServiceId_fkey" FOREIGN KEY ("contratedServiceId") REFERENCES public."ContratedService"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LogoContratedItems LogoContratedItems_logoServiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoContratedItems"
    ADD CONSTRAINT "LogoContratedItems_logoServiceId_fkey" FOREIGN KEY ("logoServiceId") REFERENCES public."LogoService"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LogoProofMockups LogoProofMockups_imagesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoProofMockups"
    ADD CONSTRAINT "LogoProofMockups_imagesId_fkey" FOREIGN KEY ("imagesId") REFERENCES public."Images"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LogoProofMockups LogoProofMockups_logoProofId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoProofMockups"
    ADD CONSTRAINT "LogoProofMockups_logoProofId_fkey" FOREIGN KEY ("logoProofId") REFERENCES public."LogoProof"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LogoProof LogoProof_imagesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoProof"
    ADD CONSTRAINT "LogoProof_imagesId_fkey" FOREIGN KEY ("imagesId") REFERENCES public."Images"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LogoService LogoService_logoBriefingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoService"
    ADD CONSTRAINT "LogoService_logoBriefingId_fkey" FOREIGN KEY ("logoBriefingId") REFERENCES public."LogoBriefing"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LogoService LogoService_logoFeedbackId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoService"
    ADD CONSTRAINT "LogoService_logoFeedbackId_fkey" FOREIGN KEY ("logoFeedbackId") REFERENCES public."LogoFeedback"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LogoService LogoService_logoProofId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoService"
    ADD CONSTRAINT "LogoService_logoProofId_fkey" FOREIGN KEY ("logoProofId") REFERENCES public."LogoProof"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LogoService LogoService_serviceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LogoService"
    ADD CONSTRAINT "LogoService_serviceTypeId_fkey" FOREIGN KEY ("serviceTypeId") REFERENCES public."ServiceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PackagesServices PackagesServices_packageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PackagesServices"
    ADD CONSTRAINT "PackagesServices_packageId_fkey" FOREIGN KEY ("packageId") REFERENCES public."Packages"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PackagesServices PackagesServices_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PackagesServices"
    ADD CONSTRAINT "PackagesServices_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public."Service"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PaymentsServices PaymentsServices_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentsServices"
    ADD CONSTRAINT "PaymentsServices_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PaymentsServices PaymentsServices_companiesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentsServices"
    ADD CONSTRAINT "PaymentsServices_companiesId_fkey" FOREIGN KEY ("companiesId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PaymentsServices PaymentsServices_packagesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentsServices"
    ADD CONSTRAINT "PaymentsServices_packagesId_fkey" FOREIGN KEY ("packagesId") REFERENCES public."Packages"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PaymentsServices PaymentsServices_paymentsId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentsServices"
    ADD CONSTRAINT "PaymentsServices_paymentsId_fkey" FOREIGN KEY ("paymentsId") REFERENCES public."Payments"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PaymentsServices PaymentsServices_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentsServices"
    ADD CONSTRAINT "PaymentsServices_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public."Service"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payments Payments_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payments"
    ADD CONSTRAINT "Payments_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Payments Payments_companiesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payments"
    ADD CONSTRAINT "Payments_companiesId_fkey" FOREIGN KEY ("companiesId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ServiceTypeChoose ServiceTypeChoose_serviceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceTypeChoose"
    ADD CONSTRAINT "ServiceTypeChoose_serviceTypeId_fkey" FOREIGN KEY ("serviceTypeId") REFERENCES public."ServiceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Service Service_modelServiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Service"
    ADD CONSTRAINT "Service_modelServiceId_fkey" FOREIGN KEY ("modelServiceId") REFERENCES public."ServiceTypeChoose"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Service Service_serviceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Service"
    ADD CONSTRAINT "Service_serviceTypeId_fkey" FOREIGN KEY ("serviceTypeId") REFERENCES public."ServiceType"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SiteBriefing SiteBriefing_briefingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteBriefing"
    ADD CONSTRAINT "SiteBriefing_briefingId_fkey" FOREIGN KEY ("briefingId") REFERENCES public."Archives"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SiteContratedItems SiteContratedItems_contratedServiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteContratedItems"
    ADD CONSTRAINT "SiteContratedItems_contratedServiceId_fkey" FOREIGN KEY ("contratedServiceId") REFERENCES public."ContratedService"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SiteContratedItems SiteContratedItems_siteServiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteContratedItems"
    ADD CONSTRAINT "SiteContratedItems_siteServiceId_fkey" FOREIGN KEY ("siteServiceId") REFERENCES public."SiteService"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SiteLayoutFinished SiteLayoutFinished_layoutId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteLayoutFinished"
    ADD CONSTRAINT "SiteLayoutFinished_layoutId_fkey" FOREIGN KEY ("layoutId") REFERENCES public."Images"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SiteLayoutSelected SiteLayoutSelected_layoutId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteLayoutSelected"
    ADD CONSTRAINT "SiteLayoutSelected_layoutId_fkey" FOREIGN KEY ("layoutId") REFERENCES public."Images"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SiteLayoutsBase SiteLayoutsBase_layoutId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteLayoutsBase"
    ADD CONSTRAINT "SiteLayoutsBase_layoutId_fkey" FOREIGN KEY ("layoutId") REFERENCES public."Images"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SiteLayoutsBase SiteLayoutsBase_siteServiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteLayoutsBase"
    ADD CONSTRAINT "SiteLayoutsBase_siteServiceId_fkey" FOREIGN KEY ("siteServiceId") REFERENCES public."SiteService"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SiteService SiteService_serviceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteService"
    ADD CONSTRAINT "SiteService_serviceTypeId_fkey" FOREIGN KEY ("serviceTypeId") REFERENCES public."ServiceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SiteService SiteService_siteBriefingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteService"
    ADD CONSTRAINT "SiteService_siteBriefingId_fkey" FOREIGN KEY ("siteBriefingId") REFERENCES public."SiteBriefing"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SiteService SiteService_siteLayoutFinishedId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteService"
    ADD CONSTRAINT "SiteService_siteLayoutFinishedId_fkey" FOREIGN KEY ("siteLayoutFinishedId") REFERENCES public."SiteLayoutFinished"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SiteService SiteService_siteLayoutSelectedId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SiteService"
    ADD CONSTRAINT "SiteService_siteLayoutSelectedId_fkey" FOREIGN KEY ("siteLayoutSelectedId") REFERENCES public."SiteLayoutSelected"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SocialContratedItems SocialContratedItems_contratedServiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialContratedItems"
    ADD CONSTRAINT "SocialContratedItems_contratedServiceId_fkey" FOREIGN KEY ("contratedServiceId") REFERENCES public."ContratedService"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SocialContratedItems SocialContratedItems_socialServiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialContratedItems"
    ADD CONSTRAINT "SocialContratedItems_socialServiceId_fkey" FOREIGN KEY ("socialServiceId") REFERENCES public."SocialService"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SocialFeedShow SocialFeedShow_imagesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialFeedShow"
    ADD CONSTRAINT "SocialFeedShow_imagesId_fkey" FOREIGN KEY ("imagesId") REFERENCES public."Images"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SocialFeedShow SocialFeedShow_socialShowId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialFeedShow"
    ADD CONSTRAINT "SocialFeedShow_socialShowId_fkey" FOREIGN KEY ("socialShowId") REFERENCES public."SocialShow"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SocialService SocialService_serviceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialService"
    ADD CONSTRAINT "SocialService_serviceTypeId_fkey" FOREIGN KEY ("serviceTypeId") REFERENCES public."ServiceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SocialService SocialService_socialBriefingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialService"
    ADD CONSTRAINT "SocialService_socialBriefingId_fkey" FOREIGN KEY ("socialBriefingId") REFERENCES public."SocialBriefing"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SocialService SocialService_socialShowId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SocialService"
    ADD CONSTRAINT "SocialService_socialShowId_fkey" FOREIGN KEY ("socialShowId") REFERENCES public."SocialShow"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: User User_roleTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_roleTypeId_fkey" FOREIGN KEY ("roleTypeId") REFERENCES public."RoleType"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: buckets buckets_owner_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_owner_fkey FOREIGN KEY (owner) REFERENCES auth.users(id);


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: objects objects_owner_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_owner_fkey FOREIGN KEY (owner) REFERENCES auth.users(id);


--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: DATABASE postgres; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE postgres TO dashboard_user;


--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT ALL ON SCHEMA auth TO postgres;


--
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- Name: SCHEMA graphql_public; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA graphql_public TO postgres;
GRANT USAGE ON SCHEMA graphql_public TO anon;
GRANT USAGE ON SCHEMA graphql_public TO authenticated;
GRANT USAGE ON SCHEMA graphql_public TO service_role;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- Name: SCHEMA realtime; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA realtime TO postgres;


--
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT ALL ON SCHEMA storage TO postgres;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin;
GRANT ALL ON SCHEMA storage TO dashboard_user;


--
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;


--
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO postgres;
GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;


--
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;


--
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM postgres;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM postgres;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION get_auth(p_usename text); Type: ACL; Schema: pgbouncer; Owner: postgres
--

REVOKE ALL ON FUNCTION pgbouncer.get_auth(p_usename text) FROM PUBLIC;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO pgbouncer;


--
-- Name: FUNCTION extension(name text); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.extension(name text) TO anon;
GRANT ALL ON FUNCTION storage.extension(name text) TO authenticated;
GRANT ALL ON FUNCTION storage.extension(name text) TO service_role;
GRANT ALL ON FUNCTION storage.extension(name text) TO dashboard_user;
GRANT ALL ON FUNCTION storage.extension(name text) TO postgres;


--
-- Name: FUNCTION filename(name text); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.filename(name text) TO anon;
GRANT ALL ON FUNCTION storage.filename(name text) TO authenticated;
GRANT ALL ON FUNCTION storage.filename(name text) TO service_role;
GRANT ALL ON FUNCTION storage.filename(name text) TO dashboard_user;
GRANT ALL ON FUNCTION storage.filename(name text) TO postgres;


--
-- Name: FUNCTION foldername(name text); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.foldername(name text) TO anon;
GRANT ALL ON FUNCTION storage.foldername(name text) TO authenticated;
GRANT ALL ON FUNCTION storage.foldername(name text) TO service_role;
GRANT ALL ON FUNCTION storage.foldername(name text) TO dashboard_user;
GRANT ALL ON FUNCTION storage.foldername(name text) TO postgres;


--
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT ALL ON TABLE auth.audit_log_entries TO postgres;


--
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.flow_state TO postgres;
GRANT ALL ON TABLE auth.flow_state TO dashboard_user;


--
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.identities TO postgres;
GRANT ALL ON TABLE auth.identities TO dashboard_user;


--
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.instances TO dashboard_user;
GRANT ALL ON TABLE auth.instances TO postgres;


--
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.mfa_amr_claims TO postgres;
GRANT ALL ON TABLE auth.mfa_amr_claims TO dashboard_user;


--
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.mfa_challenges TO postgres;
GRANT ALL ON TABLE auth.mfa_challenges TO dashboard_user;


--
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.mfa_factors TO postgres;
GRANT ALL ON TABLE auth.mfa_factors TO dashboard_user;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT ALL ON TABLE auth.refresh_tokens TO postgres;


--
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.saml_providers TO postgres;
GRANT ALL ON TABLE auth.saml_providers TO dashboard_user;


--
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.saml_relay_states TO postgres;
GRANT ALL ON TABLE auth.saml_relay_states TO dashboard_user;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.schema_migrations TO dashboard_user;
GRANT ALL ON TABLE auth.schema_migrations TO postgres;


--
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.sessions TO postgres;
GRANT ALL ON TABLE auth.sessions TO dashboard_user;


--
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.sso_domains TO postgres;
GRANT ALL ON TABLE auth.sso_domains TO dashboard_user;


--
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.sso_providers TO postgres;
GRANT ALL ON TABLE auth.sso_providers TO dashboard_user;


--
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.users TO dashboard_user;
GRANT ALL ON TABLE auth.users TO postgres;


--
-- Name: TABLE "Archives"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Archives" TO anon;
GRANT ALL ON TABLE public."Archives" TO authenticated;
GRANT ALL ON TABLE public."Archives" TO service_role;


--
-- Name: SEQUENCE "Archives_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Archives_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."Archives_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."Archives_id_seq" TO service_role;


--
-- Name: TABLE "Cards"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Cards" TO anon;
GRANT ALL ON TABLE public."Cards" TO authenticated;
GRANT ALL ON TABLE public."Cards" TO service_role;


--
-- Name: SEQUENCE "Cards_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Cards_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."Cards_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."Cards_id_seq" TO service_role;


--
-- Name: TABLE "Client"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Client" TO anon;
GRANT ALL ON TABLE public."Client" TO authenticated;
GRANT ALL ON TABLE public."Client" TO service_role;


--
-- Name: SEQUENCE "Client_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Client_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."Client_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."Client_id_seq" TO service_role;


--
-- Name: TABLE "Companies"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Companies" TO anon;
GRANT ALL ON TABLE public."Companies" TO authenticated;
GRANT ALL ON TABLE public."Companies" TO service_role;


--
-- Name: SEQUENCE "Companies_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Companies_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."Companies_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."Companies_id_seq" TO service_role;


--
-- Name: TABLE "ContratedService"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."ContratedService" TO anon;
GRANT ALL ON TABLE public."ContratedService" TO authenticated;
GRANT ALL ON TABLE public."ContratedService" TO service_role;


--
-- Name: SEQUENCE "ContratedService_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."ContratedService_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."ContratedService_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."ContratedService_id_seq" TO service_role;


--
-- Name: TABLE "Employee"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Employee" TO anon;
GRANT ALL ON TABLE public."Employee" TO authenticated;
GRANT ALL ON TABLE public."Employee" TO service_role;


--
-- Name: SEQUENCE "Employee_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Employee_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."Employee_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."Employee_id_seq" TO service_role;


--
-- Name: TABLE "Errors"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Errors" TO anon;
GRANT ALL ON TABLE public."Errors" TO authenticated;
GRANT ALL ON TABLE public."Errors" TO service_role;


--
-- Name: SEQUENCE "Errors_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Errors_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."Errors_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."Errors_id_seq" TO service_role;


--
-- Name: TABLE "Images"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Images" TO anon;
GRANT ALL ON TABLE public."Images" TO authenticated;
GRANT ALL ON TABLE public."Images" TO service_role;


--
-- Name: SEQUENCE "Images_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Images_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."Images_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."Images_id_seq" TO service_role;


--
-- Name: TABLE "Lead"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Lead" TO anon;
GRANT ALL ON TABLE public."Lead" TO authenticated;
GRANT ALL ON TABLE public."Lead" TO service_role;


--
-- Name: SEQUENCE "Lead_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Lead_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."Lead_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."Lead_id_seq" TO service_role;


--
-- Name: TABLE "LogoArchives"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."LogoArchives" TO anon;
GRANT ALL ON TABLE public."LogoArchives" TO authenticated;
GRANT ALL ON TABLE public."LogoArchives" TO service_role;


--
-- Name: SEQUENCE "LogoArchives_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."LogoArchives_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."LogoArchives_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."LogoArchives_id_seq" TO service_role;


--
-- Name: TABLE "LogoBriefing"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."LogoBriefing" TO anon;
GRANT ALL ON TABLE public."LogoBriefing" TO authenticated;
GRANT ALL ON TABLE public."LogoBriefing" TO service_role;


--
-- Name: SEQUENCE "LogoBriefing_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."LogoBriefing_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."LogoBriefing_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."LogoBriefing_id_seq" TO service_role;


--
-- Name: TABLE "LogoContratedItems"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."LogoContratedItems" TO anon;
GRANT ALL ON TABLE public."LogoContratedItems" TO authenticated;
GRANT ALL ON TABLE public."LogoContratedItems" TO service_role;


--
-- Name: SEQUENCE "LogoContratedItems_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."LogoContratedItems_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."LogoContratedItems_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."LogoContratedItems_id_seq" TO service_role;


--
-- Name: TABLE "LogoFeedback"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."LogoFeedback" TO anon;
GRANT ALL ON TABLE public."LogoFeedback" TO authenticated;
GRANT ALL ON TABLE public."LogoFeedback" TO service_role;


--
-- Name: SEQUENCE "LogoFeedback_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."LogoFeedback_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."LogoFeedback_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."LogoFeedback_id_seq" TO service_role;


--
-- Name: TABLE "LogoProof"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."LogoProof" TO anon;
GRANT ALL ON TABLE public."LogoProof" TO authenticated;
GRANT ALL ON TABLE public."LogoProof" TO service_role;


--
-- Name: TABLE "LogoProofMockups"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."LogoProofMockups" TO anon;
GRANT ALL ON TABLE public."LogoProofMockups" TO authenticated;
GRANT ALL ON TABLE public."LogoProofMockups" TO service_role;


--
-- Name: SEQUENCE "LogoProofMockups_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."LogoProofMockups_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."LogoProofMockups_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."LogoProofMockups_id_seq" TO service_role;


--
-- Name: SEQUENCE "LogoProof_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."LogoProof_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."LogoProof_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."LogoProof_id_seq" TO service_role;


--
-- Name: TABLE "LogoService"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."LogoService" TO anon;
GRANT ALL ON TABLE public."LogoService" TO authenticated;
GRANT ALL ON TABLE public."LogoService" TO service_role;


--
-- Name: SEQUENCE "LogoService_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."LogoService_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."LogoService_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."LogoService_id_seq" TO service_role;


--
-- Name: TABLE "Packages"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Packages" TO anon;
GRANT ALL ON TABLE public."Packages" TO authenticated;
GRANT ALL ON TABLE public."Packages" TO service_role;


--
-- Name: TABLE "PackagesServices"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."PackagesServices" TO anon;
GRANT ALL ON TABLE public."PackagesServices" TO authenticated;
GRANT ALL ON TABLE public."PackagesServices" TO service_role;


--
-- Name: SEQUENCE "PackagesServices_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."PackagesServices_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."PackagesServices_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."PackagesServices_id_seq" TO service_role;


--
-- Name: SEQUENCE "Packages_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Packages_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."Packages_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."Packages_id_seq" TO service_role;


--
-- Name: TABLE "Payments"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Payments" TO anon;
GRANT ALL ON TABLE public."Payments" TO authenticated;
GRANT ALL ON TABLE public."Payments" TO service_role;


--
-- Name: TABLE "PaymentsServices"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."PaymentsServices" TO anon;
GRANT ALL ON TABLE public."PaymentsServices" TO authenticated;
GRANT ALL ON TABLE public."PaymentsServices" TO service_role;


--
-- Name: SEQUENCE "PaymentsServices_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."PaymentsServices_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."PaymentsServices_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."PaymentsServices_id_seq" TO service_role;


--
-- Name: SEQUENCE "Payments_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Payments_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."Payments_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."Payments_id_seq" TO service_role;


--
-- Name: TABLE "RoleType"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."RoleType" TO anon;
GRANT ALL ON TABLE public."RoleType" TO authenticated;
GRANT ALL ON TABLE public."RoleType" TO service_role;


--
-- Name: SEQUENCE "RoleType_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."RoleType_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."RoleType_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."RoleType_id_seq" TO service_role;


--
-- Name: TABLE "Service"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Service" TO anon;
GRANT ALL ON TABLE public."Service" TO authenticated;
GRANT ALL ON TABLE public."Service" TO service_role;


--
-- Name: TABLE "ServiceType"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."ServiceType" TO anon;
GRANT ALL ON TABLE public."ServiceType" TO authenticated;
GRANT ALL ON TABLE public."ServiceType" TO service_role;


--
-- Name: TABLE "ServiceTypeChoose"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."ServiceTypeChoose" TO anon;
GRANT ALL ON TABLE public."ServiceTypeChoose" TO authenticated;
GRANT ALL ON TABLE public."ServiceTypeChoose" TO service_role;


--
-- Name: SEQUENCE "ServiceTypeChoose_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."ServiceTypeChoose_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."ServiceTypeChoose_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."ServiceTypeChoose_id_seq" TO service_role;


--
-- Name: SEQUENCE "ServiceType_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."ServiceType_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."ServiceType_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."ServiceType_id_seq" TO service_role;


--
-- Name: SEQUENCE "Service_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Service_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."Service_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."Service_id_seq" TO service_role;


--
-- Name: TABLE "SiteBriefing"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."SiteBriefing" TO anon;
GRANT ALL ON TABLE public."SiteBriefing" TO authenticated;
GRANT ALL ON TABLE public."SiteBriefing" TO service_role;


--
-- Name: SEQUENCE "SiteBriefing_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."SiteBriefing_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."SiteBriefing_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."SiteBriefing_id_seq" TO service_role;


--
-- Name: TABLE "SiteContratedItems"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."SiteContratedItems" TO anon;
GRANT ALL ON TABLE public."SiteContratedItems" TO authenticated;
GRANT ALL ON TABLE public."SiteContratedItems" TO service_role;


--
-- Name: SEQUENCE "SiteContratedItems_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."SiteContratedItems_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."SiteContratedItems_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."SiteContratedItems_id_seq" TO service_role;


--
-- Name: TABLE "SiteLayoutFinished"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."SiteLayoutFinished" TO anon;
GRANT ALL ON TABLE public."SiteLayoutFinished" TO authenticated;
GRANT ALL ON TABLE public."SiteLayoutFinished" TO service_role;


--
-- Name: SEQUENCE "SiteLayoutFinished_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."SiteLayoutFinished_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."SiteLayoutFinished_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."SiteLayoutFinished_id_seq" TO service_role;


--
-- Name: TABLE "SiteLayoutSelected"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."SiteLayoutSelected" TO anon;
GRANT ALL ON TABLE public."SiteLayoutSelected" TO authenticated;
GRANT ALL ON TABLE public."SiteLayoutSelected" TO service_role;


--
-- Name: SEQUENCE "SiteLayoutSelected_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."SiteLayoutSelected_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."SiteLayoutSelected_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."SiteLayoutSelected_id_seq" TO service_role;


--
-- Name: TABLE "SiteLayoutsBase"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."SiteLayoutsBase" TO anon;
GRANT ALL ON TABLE public."SiteLayoutsBase" TO authenticated;
GRANT ALL ON TABLE public."SiteLayoutsBase" TO service_role;


--
-- Name: SEQUENCE "SiteLayoutsBase_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."SiteLayoutsBase_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."SiteLayoutsBase_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."SiteLayoutsBase_id_seq" TO service_role;


--
-- Name: TABLE "SiteService"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."SiteService" TO anon;
GRANT ALL ON TABLE public."SiteService" TO authenticated;
GRANT ALL ON TABLE public."SiteService" TO service_role;


--
-- Name: SEQUENCE "SiteService_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."SiteService_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."SiteService_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."SiteService_id_seq" TO service_role;


--
-- Name: TABLE "SocialBriefing"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."SocialBriefing" TO anon;
GRANT ALL ON TABLE public."SocialBriefing" TO authenticated;
GRANT ALL ON TABLE public."SocialBriefing" TO service_role;


--
-- Name: SEQUENCE "SocialBriefing_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."SocialBriefing_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."SocialBriefing_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."SocialBriefing_id_seq" TO service_role;


--
-- Name: TABLE "SocialContratedItems"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."SocialContratedItems" TO anon;
GRANT ALL ON TABLE public."SocialContratedItems" TO authenticated;
GRANT ALL ON TABLE public."SocialContratedItems" TO service_role;


--
-- Name: SEQUENCE "SocialContratedItems_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."SocialContratedItems_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."SocialContratedItems_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."SocialContratedItems_id_seq" TO service_role;


--
-- Name: TABLE "SocialFeedShow"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."SocialFeedShow" TO anon;
GRANT ALL ON TABLE public."SocialFeedShow" TO authenticated;
GRANT ALL ON TABLE public."SocialFeedShow" TO service_role;


--
-- Name: SEQUENCE "SocialFeedShow_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."SocialFeedShow_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."SocialFeedShow_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."SocialFeedShow_id_seq" TO service_role;


--
-- Name: TABLE "SocialService"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."SocialService" TO anon;
GRANT ALL ON TABLE public."SocialService" TO authenticated;
GRANT ALL ON TABLE public."SocialService" TO service_role;


--
-- Name: SEQUENCE "SocialService_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."SocialService_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."SocialService_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."SocialService_id_seq" TO service_role;


--
-- Name: TABLE "SocialShow"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."SocialShow" TO anon;
GRANT ALL ON TABLE public."SocialShow" TO authenticated;
GRANT ALL ON TABLE public."SocialShow" TO service_role;


--
-- Name: SEQUENCE "SocialShow_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."SocialShow_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."SocialShow_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."SocialShow_id_seq" TO service_role;


--
-- Name: TABLE "Tables"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Tables" TO anon;
GRANT ALL ON TABLE public."Tables" TO authenticated;
GRANT ALL ON TABLE public."Tables" TO service_role;


--
-- Name: SEQUENCE "Tables_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Tables_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."Tables_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."Tables_id_seq" TO service_role;


--
-- Name: TABLE "User"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."User" TO anon;
GRANT ALL ON TABLE public."User" TO authenticated;
GRANT ALL ON TABLE public."User" TO service_role;


--
-- Name: SEQUENCE "User_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."User_id_seq" TO anon;
GRANT ALL ON SEQUENCE public."User_id_seq" TO authenticated;
GRANT ALL ON SEQUENCE public."User_id_seq" TO service_role;


--
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets TO anon;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.buckets TO service_role;
GRANT ALL ON TABLE storage.buckets TO postgres;


--
-- Name: TABLE migrations; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.migrations TO anon;
GRANT ALL ON TABLE storage.migrations TO authenticated;
GRANT ALL ON TABLE storage.migrations TO service_role;
GRANT ALL ON TABLE storage.migrations TO postgres;


--
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.objects TO anon;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT ALL ON TABLE storage.objects TO service_role;
GRANT ALL ON TABLE storage.objects TO postgres;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES  TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS  TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES  TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES  TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS  TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON TABLES  TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: pgsodium; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium GRANT ALL ON SEQUENCES  TO pgsodium_keyholder;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: pgsodium; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium GRANT ALL ON TABLES  TO pgsodium_keyholder;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: pgsodium_masks; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium_masks GRANT ALL ON SEQUENCES  TO pgsodium_keyiduser;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: pgsodium_masks; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium_masks GRANT ALL ON FUNCTIONS  TO pgsodium_keyiduser;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: pgsodium_masks; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium_masks GRANT ALL ON TABLES  TO pgsodium_keyiduser;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES  TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS  TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES  TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO service_role;


--
-- PostgreSQL database dump complete
--

